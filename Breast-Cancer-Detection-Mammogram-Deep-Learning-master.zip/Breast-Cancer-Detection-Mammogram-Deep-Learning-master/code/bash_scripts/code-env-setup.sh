#!/bin/bash
#Author: Adam Jaamour
# ----------------------------
echo "Setting up terminal session to run code for dissertation"
source /cs/scratch/agj6/tf2/venv/bin/activate
cd  ~/Projects/Breast-Cancer-Detection-and-Segmentation/code/src/
