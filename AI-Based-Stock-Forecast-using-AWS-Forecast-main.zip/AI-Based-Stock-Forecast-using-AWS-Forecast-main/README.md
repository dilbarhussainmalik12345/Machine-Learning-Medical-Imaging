# AI-Based-Stock-Forecast-using-AWS-Forecast
Stock Forecasting System using AWS forecast. 


Course Objectives

Three learning objectives:

 1. Explore the core features and functionalities provided by Amazon Forecast
 2. How to upload train and build your model for predicting Stock Market Prices
 3. How to improve the accuracy of the model and understand the key performance metrics to gauge the accuracy. 
