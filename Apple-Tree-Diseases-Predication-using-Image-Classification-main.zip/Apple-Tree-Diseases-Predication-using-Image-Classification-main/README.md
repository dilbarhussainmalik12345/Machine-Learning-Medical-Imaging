# Apple-Tree-Diseases-Predication-using-Image-Classification
Apple Tree Diseases Predication using Image Classification
> ***Given a photo of an apple leaf, can you accurately assess its health? This competition will challenge you to distinguish between leaves which are healthy, those which are infected with apple rust, those that have apple scab, and those with more than one disease.***

**Dataset Link:- https://www.kaggle.com/competitions/plant-pathology-2020-fgvc7/data**
